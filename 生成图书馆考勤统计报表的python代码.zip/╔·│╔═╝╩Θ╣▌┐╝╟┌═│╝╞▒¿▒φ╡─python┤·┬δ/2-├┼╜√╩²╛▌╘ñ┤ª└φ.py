import pandas as pd  
from pypinyin import lazy_pinyin  
  
# 文件路径  
file_path = 'D:\\wxyy\\library_access_data.xlsx'  
  
# 读取Excel文件  
df = pd.read_excel(file_path)  
  
# 确保刷卡日期和刷卡时间是正确的数据类型  
df['ThroughTime'] = pd.to_datetime(df['ThroughTime']).dt.date  
df['CheckTime'] = pd.to_datetime(df['CheckTime']).dt.time  
  
# 对数据进行排序，确保进馆和出馆的记录是按时间顺序的  
df.sort_values(by=['CardID', 'ThroughTime', 'CheckTime'], inplace=True)  
  
# 获取所有员工和日期的组合  
all_employees = df['CardID'].unique()  
all_dates = df['ThroughTime'].unique()  
all_combinations = [(emp, date) for emp in all_employees for date in all_dates]  
  
# 初始化考勤表  
attendance_records = pd.DataFrame(all_combinations, columns=['CardID', 'ThroughTime'])  
attendance_records['Name'] = attendance_records['CardID'].map(df.set_index('CardID')['Name'].to_dict())  
attendance_records['Depart'] = attendance_records['CardID'].map(df.set_index('CardID')['Depart'].to_dict())  
attendance_records['StartTime'] = None  
attendance_records['EndTime'] = None  
  
# 填充上下班时间  
for idx, row in attendance_records.iterrows():  
    emp_df = df[(df['CardID'] == row['CardID']) & (df['ThroughTime'] == row['ThroughTime'])]  
    in_times = emp_df[emp_df['Direction'] == '进馆']['CheckTime']  
    out_times = emp_df[emp_df['Direction'] == '出馆']['CheckTime']  
      
    if not in_times.empty:  
        attendance_records.at[idx, 'StartTime'] = in_times.min()  
    if not out_times.empty:  
        attendance_records.at[idx, 'EndTime'] = out_times.max()  
  
# 使用pypinyin将中文姓名转换为拼音，并添加为新列  
attendance_records['Pinyin'] = attendance_records['Name'].apply(lambda x: ' '.join(lazy_pinyin(x)))  
  
# 按姓名的中文拼音、刷卡日期、部门排序  
attendance_records.sort_values(by=['Pinyin', 'ThroughTime', 'Depart'], inplace=True)  
  
# 删除拼音列（如果需要）  
attendance_records.drop(columns=['Pinyin'], inplace=True)  
  
# 保存考勤表为新的Excel文件  
output_path = 'D:\\wxyy\\swipes.xlsx'  
attendance_records.to_excel(output_path, index=False)  
  
print("考勤表已生成并保存在：", output_path)