import pandas as pd  
from datetime import datetime, timedelta    
# 定义文件路径  
attendance_path = 'D:/wxyy/swipes.xlsx'  
scheduling_path = 'D:/wxyy/scheduling.xlsx'  
leave_records_path = 'D:/wxyy/leave_records.xlsx'  
  
# 读取数据  
attendance = pd.read_excel(attendance_path)  
scheduling = pd.read_excel(scheduling_path)  
leave_records = pd.read_excel(leave_records_path)  
  
# 转换日期格式  
attendance['ThroughTime'] = pd.to_datetime(attendance['ThroughTime'])  
scheduling['schedule_date'] = pd.to_datetime(scheduling['schedule_date'])  
leave_records['start_date'] = pd.to_datetime(leave_records['start_date'])  
leave_records['end_date'] = pd.to_datetime(leave_records['end_date'])  
  
# 设置日期范围  
start_date = pd.Timestamp('2024-06-24')  
end_date = pd.Timestamp('2024-06-30')  
  
# 初始化一个空的DataFrame，用于存储结果  
results_df = pd.DataFrame(columns=[  
    '日期', '员工姓名', '上班时间', '下班时间', '迟到（分钟）', '早退（分钟）', '请假类型', '部门','班次'  
])  
  
# 处理每一天  
for date in pd.date_range(start=start_date, end=end_date):  
    current_date = date.strftime('%Y-%m-%d')  
      
    # 获取当天的排班信息  
    current_scheduling = scheduling[scheduling['schedule_date'] == date]  
      
    # 获取当天的考勤信息  
    current_attendance = attendance[(attendance['ThroughTime'] >= date) & (attendance['ThroughTime'] < date + pd.Timedelta(days=1))]  
      
    # 获取当天的请假信息  
    current_leave = leave_records[(leave_records['start_date'] <= date) & (leave_records['end_date'] >= date)]  
      
    # 合并信息  
    for _, row in current_scheduling.iterrows():  
        card_id = row['CardID']  
        name = row['Name']
        depart=row['Depart']  
        shift_start = row['shift_start']
        shift_end = row['shift_end']
        schedule=row['schedule_name']#班次名称
           
# 假设 shift_start 和 shift_end 也是字符串，需要转换为 datetime  
        shift_start=row['shift_start']
        shift_end=row['shift_end']
        if type(shift_start) is float:
           shift_start ='00:00:00'
        if type(shift_end) is float:
           shift_end ='00:00:00'
        shift_start = datetime.strptime(shift_start, '%H:%M:%S')  # 假设 shift_start_str 是字符串格式的时间  
        shift_end = datetime.strptime(shift_end, '%H:%M:%S')      # 假设 shift_end_str 是字符串格式的时间  
        # 查找当天的考勤记录  
        attendance_row = current_attendance[current_attendance['CardID'] == card_id]  
        if not attendance_row.empty: 
            actual_start=attendance_row['StartTime'].iloc[0]
            actual_end =attendance_row['EndTime'].iloc[0]
            #自己加的为了解决datetime.strptime的第一个参数必须是str型的问题
            if type(actual_start) is float:  
               actual_start = '00:00:00'  
            if type(actual_end) is float:  
               actual_end = '00:00:00' 
            
            actual_start = datetime.strptime(actual_start, '%H:%M:%S')  # 转换为 datetime 
            actual_end = datetime.strptime(actual_end, '%H:%M:%S')     # 转换为 datetime
               
        else:  
            actual_start = None  
            actual_end = None  
        # 查找请假记录  
        leave_row = current_leave[current_leave['CardID'] == card_id]  
        if not leave_row.empty:  
            leave_type = leave_row['leave_type'].iloc[0]  
        else:  
            leave_type = None  
          
        # 计算迟到和早退
        #late_minutes = (actual_start - shift_start).seconds // 60 if actual_start else None  
        #early_leave_minutes = (shift_end - actual_end).seconds // 60 if actual_end else None  
        late_minutes = 0 if actual_start and actual_start <= shift_start else (actual_start - shift_start).seconds // 60 if actual_start else None  
        #非休息日签到未刷卡签到记为未鉴到
        if late_minutes == 0 and schedule != '休息':
            late_minutes='未签到'
             
        leave_early_minutes = 0 if actual_end and actual_end >= shift_end else (shift_end - actual_end).seconds // 60 if actual_end else None  
         #非休息日签到未刷卡签离记为未鉴到，1050对应的是17；30下班的，960对应的是16：00下班的，1320对应的是22：00下班的。
        if (leave_early_minutes == 1050 or leave_early_minutes == 960 or leave_early_minutes == 1320) and schedule != '休息':           
           leave_early_minutes='未签到'
        
        #特别补充说明：如果当天是休息，那么职工即使刷卡了，则迟到和早退时间都为0。而不应该计算或未签到。
        if schedule == '休息': 
           late_minutes= 0
           leave_early_minutes = 0    
           
        #特别补充说明：如果当天是请假了，那么迟到和早退时间都为0。
        if leave_type != None:
           late_minutes= 0
           leave_early_minutes = 0
           #print(late_minutes,leave_early_minutes,leave_type)
           
           # 创建一条新的DataFrame记录  
        new_row_df = pd.DataFrame({  
            '日期': [current_date],  
            '员工姓名': [name],  
            '上班时间': actual_start.strftime('%H:%M:%S') if actual_start else None,  
            '下班时间': actual_end.strftime('%H:%M:%S') if actual_end else None,    
            '迟到（分钟）': [late_minutes],  
            '早退（分钟）': [leave_early_minutes],  
            '请假类型': [leave_type],  
            '部门': [depart],
            '班次':[schedule]  
        })  
          
        # 将新记录添加到结果DataFrame中  
        results_df = pd.concat([results_df, new_row_df], ignore_index=True)  
  


# 输出结果到Excel
output_path = 'D:/wxyy/attendance_summary.xlsx'  
results_df.to_excel(output_path, index=False) 
print(f'员工勤勤信息详细已生成并保存到：{output_path}')