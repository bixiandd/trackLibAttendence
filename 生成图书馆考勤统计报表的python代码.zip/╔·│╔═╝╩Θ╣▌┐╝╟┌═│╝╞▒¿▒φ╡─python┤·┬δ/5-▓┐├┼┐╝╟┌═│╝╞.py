import pandas as pd  
from datetime import datetime  
  
# 读取Excel文件  
df = pd.read_excel('D:/wxyy/attendance_summary.xlsx')  
  
# 转换日期列为日期格式  
df['日期'] = pd.to_datetime(df['日期'])  
  
# 筛选指定日期范围内的数据  
start_date = datetime(2024, 6, 24)  
end_date = datetime(2024, 6, 30)  
df_filtered = df[(df['日期'] >= start_date) & (df['日期'] <= end_date)]  
  
# 初始化统计列  
columns_to_add = ['迟到分钟数', '早退分钟数', '迟到次数', '早退次数', '警示次数', '未签到次数', '请假天数', '旷工天数','出勤天数','应上班天数']  
for col in columns_to_add:  
    df_filtered[col] = 0  
  
# 处理迟到、早退、未签到、请假和旷工情况  
for index, row in df_filtered.iterrows():  
    # 处理迟到  
    if '未签到' not in str(row['迟到（分钟）']):  
        late_minutes = int(row['迟到（分钟）'])  
        if late_minutes > 0:  
            if late_minutes <= 10:  
                df_filtered.at[index, '警示次数'] += 1  
            elif late_minutes <= 60:  
                df_filtered.at[index, '迟到次数'] += 1  
            elif late_minutes <= 120:  
                df_filtered.at[index, '迟到次数'] += 2  
            else:  
                df_filtered.at[index, '旷工天数'] += 0.5  
        df_filtered.at[index, '迟到分钟数'] += late_minutes  
    else:  
        df_filtered.at[index, '未签到次数'] += 1  
  
    # 处理早退  
    if '未签到' not in str(row['早退（分钟）']):  
        early_leave_minutes = int(row['早退（分钟）'])  
        if early_leave_minutes > 0:  
            if early_leave_minutes <= 30:  
                df_filtered.at[index, '早退次数'] += 1  
            elif early_leave_minutes <= 60:  
                df_filtered.at[index, '早退次数'] += 2  
            else:  
                df_filtered.at[index, '旷工天数'] += 0.5  
        df_filtered.at[index, '早退分钟数'] += early_leave_minutes  
    else:  
        df_filtered.at[index, '未签到次数'] += 1  
  
    # 处理请假  
    if pd.notnull(row['请假类型']):  
        df_filtered.at[index, '请假天数'] += 1  
    
    #处理出勤
    if pd.notnull(row['请假类型']) or (row['班次']=='休息'):
       df_filtered.at[index, '出勤天数'] += 0
    else:  
      df_filtered.at[index, '出勤天数'] += 1
    #处理应上班天数
    if row['班次']=='休息':
       df_filtered.at[index, '应上班天数'] += 0
    else:  
      df_filtered.at[index, '应上班天数'] += 1   
# 按员工姓名和日期分组，并计算每天的考勤统计  
daily_attendance = df_filtered.groupby(['部门','员工姓名', '日期']).agg({  
    '迟到分钟数': 'sum',  
    '早退分钟数': 'sum',  
    '迟到次数': 'sum',  
    '早退次数': 'sum',  
    '警示次数': 'sum',  
    '未签到次数': 'sum',  
    '请假天数': 'sum',  
    '旷工天数': 'sum' ,
    '出勤天数':'sum', 
    '应上班天数': 'sum'
}).reset_index()  
# 对daily_attendance数据框按照“部门”分组，并计算各项的总和  
department_summary = daily_attendance.groupby('部门').agg({  
    '迟到次数': 'sum',  
    '早退次数': 'sum',  
    '警示次数': 'sum',  
    '未签到次数': 'sum',  
    '请假天数': 'sum',  
    '旷工天数': 'sum',  
    '出勤天数': 'sum',
    '应上班天数':'sum'  
}).reset_index()  
  
# 重命名列，使其更符合需求描述  
department_summary.rename(columns={  
    '迟到次数': '迟到总次数',  
    '早退次数': '早退总次数',  
    '警示次数': '警示总次数',  
    '未签到次数': '未签到总次数',  
    '请假天数': '请假总天数',  
    '旷工天数': '旷工总天数',  
    '出勤天数': '出勤天数',
    '应上班天数':'应上班天数'  
}, inplace=True)  
  
# 重命名列，使其更具描述性  
department_summary.columns = ['部门', '迟到总次数', '早退总次数', '警示总次数', '未签到总次数', '请假总天数', '旷工总天数', '出勤天数','应上班天数']  
  
# 将结果写入新的Excel文件  
output_file = 'D:/wxyy/depart_attendance_summary.xlsx'  
department_summary.to_excel(output_file, index=False)  
  
print("部门考勤统计已写入Excel文件：", output_file)