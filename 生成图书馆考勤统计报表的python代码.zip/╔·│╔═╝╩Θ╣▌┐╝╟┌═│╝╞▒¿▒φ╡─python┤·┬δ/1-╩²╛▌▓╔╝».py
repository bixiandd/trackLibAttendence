#在运行程序前，需在cmd中安装使用Python的几个库：pandas 用于数据处理和sqlalchemy 用于连接MySQL数据库
#pip install pandas sqlalchemy openpyxl pymysql
import pandas as pd  
from sqlalchemy import create_engine  
  
# 数据库配置  
username = 'your_username'  
password = 'your_password'  
host = 'your_host'  
database = 'your_database'  
  
# 创建数据库连接引擎  
engine = create_engine(f'mysql+pymysql://{username}:{password}@{host}/{database}')  
  
# SQL查询语句  
query = """  
SELECT CardID, Name, ThroughTime, CheckTime, Depart, Direction  
FROM access  
WHERE ThroughTime BETWEEN '2024-06-24' AND '2024-06-30'  
AND Depart = '图书馆'  
"""  
  
# 使用pandas的read_sql_query函数读取数据  
df = pd.read_sql_query(query, engine)  
  
# 将数据保存到Excel文件  
df.to_excel('D://wxyx//library_access_data.xlsx', index=False)  
  
print('数据已保存到Excel文件中。')